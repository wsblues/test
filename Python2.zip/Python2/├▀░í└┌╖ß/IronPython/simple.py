def HelloWorld():
    print("Hello World")

def HelloWorld2(value ):
    print("Hello 2, ", value)

def ListTest():
    lst = ["aa", "bb", "cc"]
    return lst
