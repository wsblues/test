# GUI_independent_msg.py
from tkinter import messagebox as msg 
msg.showinfo("Python GUI using tkinter\n올해는 2018년")
