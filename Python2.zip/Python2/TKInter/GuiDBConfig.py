# GuiDBConfig.py
#접속 관련 정보를 딕셔너리에 저장
dbConfig = {
    'user':'jonathan',
    'password':'1234',
    'host':'127.0.0.1',
}